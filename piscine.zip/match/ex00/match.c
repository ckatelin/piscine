/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   match.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/09 19:38:24 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/10 18:27:20 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	kill(char *s2)
{
	int i;
	int j;

	i = 0;
	while (s2[i] != '\0')
	{
		if (s2[i] == '*' && s2[i + 1] == '*')
		{
			j = i;
			while (s2[j] != '\0')
			{
				s2[j] = s2[j + 1];
				j++;
			}
			i = -1;
		}
		i++;
	}
}

int		rec(char *s1, char *s2)
{
	if ((*s1 != '\0') && (*s2 == '*'))
		return (rec(s1 + 1, s2) || rec(s1, s2 + 1));
	if (*s1 == '\0' && *s2 == '*')
		return (rec(s1, s2 + 1));
	if (*s1 == '\0' && *s2 == '\0')
		return (1);
	if (*s1 == *s2)
		return (rec(s1 + 1, s2 + 1));
	return (0);
}

int		match(char *s1, char *s2)
{
	int res;

	kill(s2);
	res = rec(s1, s2);
	return (res);
}
