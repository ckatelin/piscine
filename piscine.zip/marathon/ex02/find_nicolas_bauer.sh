#!/bin/sh
cat $1 | grep -i "Nicolas\tBauer" | rev | cat -f 2 | rev | grep "-"
