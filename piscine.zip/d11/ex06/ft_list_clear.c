/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_clear.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 21:01:56 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/13 21:46:22 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdlib.h>

void	rem(t_list *list)
{
	if (list)
	{
		rem(list->next);
		free(list);
	}
}

void	ft_list_clear(t_list **begin_list)
{
	rem(*begin_list);
}
