/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_insert_data.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/15 21:05:45 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/15 21:38:27 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_insert_data(t_btree **root, void *item,
			int (*cmpf)(void *, void *))
{
	t_btree	*elem;

	elem = *root;
	if (!root || !*root)
		*root = btree_create_node(item);
	else if (cmpf(item, elem->item) < 0 && elem->left)
		btree_insert_data(&elem->left, item, cmpf);
	else if (!elem->left)
		elem->left = btree_create_node(item);
	else if (cmpf(item, elem->item) >= 0 && elem->right)
		btree_insert_data(&elem->right, item, cmpf);
	else if (!elem->right)
		elem->right = btree_create_node(item);
}
