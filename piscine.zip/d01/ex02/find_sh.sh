#!/bin/sh
find . -name '*.sh' | sed 's/.*\///' | cut -f 1 -d .
