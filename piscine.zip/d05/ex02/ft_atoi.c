/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/04 10:54:50 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/05 16:03:06 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

struct			s_names
{
	int			mns;
	int			res;
	int			f;
	int			pls;
	char		s;
};

struct s_names	t = {0, 0, 0, 0, '0'};

int				ft_atoi(char *str)
{
	while ((t.s = *str++) != '\0')
	{
		if ((t.s == ' ' || t.s == '\t' || t.s == '\v' || t.s == '\r' ||
				t.s == '\n' || t.s == '\f' || t.s == '+') && t.f == 0
				&& t.mns == 0 && t.pls == 0)
		{
			if (t.s == '+')
				t.pls = 1;
			continue;
		}
		if (t.s == '-' && (*str >= 0 || *str <= '9') &&
				t.mns == 0 && t.f == 0)
		{
			t.mns = 1;
			continue;
		}
		if (t.s < '0' || t.s > '9')
			break ;
		t.f = 1;
		t.res = t.res * 10 + (t.s - '0');
	}
	if (t.mns == 1)
		return (t.res * (-1));
	return (t.res);
}
