/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 17:32:13 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/12 21:52:26 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

void	print_error(void);
int		check(char znak);
void	ft_putnbr(int nb);
int		ft_atoi(char *str);
void	ft_putchar(char c);
int		div(int a, int b);
int		mod(int a, int b);
int		plus(int a, int b);
int		minus(int a, int b);
int		mult(int a, int b);
int		calc(int a, int b, int oper);

#endif
