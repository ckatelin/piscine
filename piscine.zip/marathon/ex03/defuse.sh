touch -r "bomb.txt" -A '-000001' "bomb.txt" && stat -t bomb.txt | cut -d ' ' -f9
