git ls-files --other -i --exclude-standard
