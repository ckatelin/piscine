/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 07:55:07 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/08 17:07:48 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		words(char *str)
{
	int w;
	int k;

	k = 0;
	w = 0;
	while (str[k])
	{
		while (str[k] == '\n' || str[k] == ' ' || str[k] == '\t')
			k++;
		while (str[k] != '\0' && str[k] != '\n' && str[k] != ' ' &&
				str[k] != '\t')
			k++;
		w++;
	}
	return (w);
}	

int		sym(char *str)
{
	int k;

	k = 0;
	while (str[k] != '\0' && str[k] != '\n' && str[k] != ' ' &&
			str[k] != '\t')
		k++;
	return (k);
}

char		**ft_split_whitespaces(char *str)
{
	int		i;
	int		j;
	int		k;
	char	**array;

	k = 0;
	i = 0;
	array = (char **)malloc(sizeof(char) * (words(str) + 1));
	while (str[k])
	{
		array[i] = (char *)malloc(sizeof(char*) * (sym(str) + 1));
		j = 0;
		while (str[k] == '\n' || str[k] == ' ' || str[k] == '\t')
			k++;
		while (str[k] != '\0' && str[k] != '\n' && str[k] != ' ' &&
				str[k] != '\t')
		{
			array[i][j] = str[k];
			j++;
			k++;
		}
		while (str[k] == '\n' || str[k] == ' ' || str[k] == '\t')
			k++;
		array[i][j] = '\n';
		k++;
		i++;
	}
	array[i - 1][j] = '\0';
	return (array);
}
