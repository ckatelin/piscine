/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_error.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/14 13:40:46 by ckatelin          #+#    #+#             */
/*   Updated: 2019/04/02 15:48:21 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	print(char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
	{
		ft_putchar(s[i], 2);
		i++;
	}
}

void	print_error(int c)
{
	int		i;
	char	*s;
	char	*s1;
	char	*s2;

	s = "File name missing.";
	s1 = "Too many arguments.";
	s2 = "open() failed";
	i = 0;
	if (c == 1)
		print(s);
	if (c > 2)
		print(s1);
	if (c == -1)
		print(s2);
}
