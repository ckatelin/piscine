/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/07 22:00:34 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/07 23:40:40 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		count(int argc, char **argv)
{
	int	k;

	k = 0;
	j = 1;
	while (j <= (argc - 1))
	{
		i = 0;
		while (argv[j][i] != '\0')
		{
			k++;
			i++;
		}
		j++;
	}
	k++;
	return (k);
}

char	*ft_concat_params(int argc, char **argv)
{
	int		i;
	int		j;
	char	*mas;
	int		k;

	k = 0;
	mas = (char *)malloc(sizeof(char) * count(agrc, agrv));
	if (argc > 0)
	{
		j = 1;
		while (j <= (argc - 1))
		{
			i = 0;
			while (argv[j][i] != '\0')
			{
				mas[k] = argv[j][i];
				k++;
				i++;
			}
			mas[k++] = '\n';
			j++;
		}
	}
	mas[k] = '\0';
	return (mas);
}
