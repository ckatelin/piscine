/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/02 18:41:35 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/02 23:38:37 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_find_next_prime(int nb)
{
	int j;
	int k;

	k = 0;
	j = 2;
	if (nb <= 1)
		return (0);
	if ((nb == 2) || (nb == 3) || (nb == 5) || (nb == 7))
		return (nb);
	while (j <= nb && k == 0)
	{
		if ((nb % j) == 0)
			k++;
		j++;
	}
	if (k == 0)
		return (nb);
	return (ft_find_next_prime(nb + 1));
}
