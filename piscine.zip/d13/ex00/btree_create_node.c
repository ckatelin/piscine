/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_create_node.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/15 19:55:11 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/15 20:49:14 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdlib.h>

t_btree	*btree_create_node(void *item)
{
	t_btree	*elem;

	elem = (t_btree *)malloc(sizeof(t_btree));
	if (elem)
	{
		elem->left = (void *)0;
		elem->right = (void *)0;
		elem->item = item;
		return (elem);
	}
	else
		return (0);
}
