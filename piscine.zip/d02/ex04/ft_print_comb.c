/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/28 16:02:38 by ckatelin          #+#    #+#             */
/*   Updated: 2019/02/28 20:46:44 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_print_comb(void)
{
	int num;
	int num1;
	int num2;
	int num3;

	num = 0;
	while (num++ <= 999)
	{
		num1 = num / 100;
		num2 = (num / 10) % 10;
		num3 = num % 10;
		if ((num1 < num2) && (num2 < num3))
		{
			ft_putchar(num1 + '0');
			ft_putchar(num2 + '0');
			ft_putchar(num3 + '0');
			if (num != 789)
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
		}
	}
}
