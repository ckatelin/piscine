/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/27 19:39:36 by ckatelin          #+#    #+#             */
/*   Updated: 2019/02/28 21:08:02 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_print_reverse_alphabet(void)
{
	char symb;

	symb = 'z';
	while (symb >= 'a')
	{
		ft_putchar(symb);
		symb--;
	}
}
