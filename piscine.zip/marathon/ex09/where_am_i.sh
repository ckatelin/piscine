#!/bin/sh
where=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | cut -d \  -f2);
if [ -z "$where" ]
then
echo "I am lost!"
else
echo "$where" | tr ' ' '\n'
fi
