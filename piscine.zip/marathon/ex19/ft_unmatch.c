/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unmatch.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 11:49:50 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/08 12:42:55 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_unmatch(int *tab, int length)
{
	int i;
	int j;
	int k;
	int num;

	if (length == 1)
		return (tab[0]);
	i = -1;
	while (++i < (length - 1))
	{
		k = 0;
		j = 0;
		while (j < length)
		{
			if (tab[i] == tab[j])
			{
				num = tab[j];
				k++;
			}
			j++;
		}
		if (k % 2 != 0)
			return (num);
	}
	return (0);
}
