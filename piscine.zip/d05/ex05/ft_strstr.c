/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/05 16:26:00 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/05 22:33:09 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

struct				s_names
{
	int				i;
	int				j;
	int				check;
};

struct s_names		s = {0, 0, 0};

char				*ft_strstr(char *str, char *to_find)
{
	while (str[s.i] != '\0')
	{
		if (str[s.i] != to_find[s.j])
			s.i++;
		else
		{
			s.check = s.i;
			while (to_find[++s.j] != '\0' && s.check == s.i)
			{
				if ((str[s.i + s.j] != to_find[s.j]) ||
					(str[s.i + s.j] == '\0'))
					s.check++;
			}
			if (s.check == s.i)
				return (str + s.i);
			s.j = 0;
			s.i++;
		}
	}
	return (0);
}
