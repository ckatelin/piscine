/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_params.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 16:48:33 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/13 21:01:01 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list		*ft_list_push_params(int ac, char **av)
{
	t_list	*list;
	int		i;

	i = 2;
	list = ft_create_elem(av[1]);
	list = list->next;
	while (i < ac)
	{
		list = ft_create_elem(av[i]);
		list = list->next;
		i++;
	}
	list = ft_create_elem(ac);
	return (list);
}
