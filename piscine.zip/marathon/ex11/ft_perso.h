/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_perso.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 04:06:36 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/08 04:14:53 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PERSO_H
# define FT_PERSO_H

#include "ft_perso.h"
#include <string.h>

# define SAVE_THE_WORLD "profession"

typedef	struct	s_perso
{
	double		life;
	int			age;
	char		*name;
	char		*profession;

}				t_perso;

#endif
