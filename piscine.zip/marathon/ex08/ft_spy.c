/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 00:26:50 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/08 01:22:17 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check(char *s1, char *s2)
{
	int i;
	int j;
	int k;

	k = 0;
	j = 0;
	i = 0;
	while (s1[i] != '\0' && s2[j] != '\0')
	{
		if(s1[i] == s2[j])
		{
			i++;
			j++;
			if (j == k)
				return (1);
		}
		else if (s1[i] == ' ')
			i++;
		else
			return (0);
	}
	return (0);
}
int	main(int argc, char **argv)
{
	int i;
	int j;

	j = 1;
	while (j < argc)
	{
		i = 0;
		while (argv[j][i] != '\0')
		{
			if (argv[j][i] >= 'A' && argv[j][i] <= 'Z')
				argv[j][i] += 32;
			++i;
		}
		if (check(argv[j], "president") || check(argv[j], "attack")
					|| check(argv[j], "bauer"))
		{
			write(1, "Alert!!!\n", 9);		
			break ;
		}
		++j;
	}
	return (0);
}
