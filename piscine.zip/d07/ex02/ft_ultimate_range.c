/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/07 17:08:20 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/07 22:00:16 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int j;

	if (min >= max)
	{
		*range = (void *)0;
		return (0);
	}
	*range = (int *)malloc(sizeof(max - min));
	if ((void *)0 == *range)
		return (0);
	i = 0;
	j = min;
	while (j < max)
	{
		(*range)[i] = j;
		i++;
		j++;
	}
	return (i);
}
