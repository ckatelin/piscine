/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_size.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 16:42:59 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/13 19:13:57 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

int			ft_list_size(t_list *begin_list)
{
	int		count;
	t_list	*elem;

	count = 0;
	elem = begin_list;
	if (begin_list)
	{
		while (elem)
		{
			elem = elem->next;
			count++;
		}
	}
	return (count);
}
