/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 14:40:00 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/12 16:00:20 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int sortup;
	int sortdown;
	int i;
	int nul;

	sortup = 0;
	sortdown = 0;
	i = 0;
	nul = 0;
	while (i < (length - 1))
	{
		if (length <= 2)
			return (1);
		if ((*f)(tab[i], tab[i + 1]) > 0)
			sortup++;
		else if ((*f)(tab[i], tab[i + 1]) < 0)
			sortdown++;
		else
			nul++;
		i++;
	}
	if ((sortup + nul) == (length - 1) || (sortdown + nul) == (length - 1))
		return (1);
	return (0);
}
