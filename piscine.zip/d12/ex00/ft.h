/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/14 22:38:19 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/14 23:01:59 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# define BUF_SIZE 4096

# include <fcntl.h>
# include <unistd.h>

void	ft_putchar(char c, int d);
void	print_error(int c);
void	print(char *s);
#endif
