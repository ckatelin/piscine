/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/07 15:04:36 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/07 17:08:40 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		*ft_range(int min, int max)
{
	int *mas;
	int k;
	int j;

	if (min >= max)
	{
		mas = (void *)0;
		return (mas);
	}
	mas = (int *)malloc(sizeof(int) * (max - min));
	if ((void *)0 == mas)
		return (mas);
	k = 0;
	j = min;
	while (j < max)
	{
		mas[k] = j;
		j++;
		k++;
	}
	return (mas);
}
