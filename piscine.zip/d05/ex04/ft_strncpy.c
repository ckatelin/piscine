/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/04 20:02:43 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/05 21:31:31 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int i;

	i = 0;
	while (n != 0 && *(src + i) != '\0')
	{
		*(dest + i) = *(src + i);
		i++;
		n--;
	}
	while (i <= sizeof(dest))
	{
		*(dest + i) = '\0';
		i++;
	}
	*(dest + sizeof(dest) + i) = '\0';
	return (dest);
}
