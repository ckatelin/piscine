/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_active_bits.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 08:55:42 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/08 09:21:17 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int				power(int nb, int power)
{
	int		res;

	res = 1;
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	while (power != 0)
	{
		res = res * nb;
		power--;
	}
	return (res);
}

unsigned int	ft_active_bits(int value)
{
	int			i;
	int			k;

	i = 0;
	k = 0;
	while (i <= 31)
	{
		if ((power(2, i) & value) == power(2, i))
			k++;
		i++;
	}
	return (k);
}
