/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 17:06:47 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/12 21:57:05 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		main(int argc, char **argv)
{
	int res;
	int oper;

	oper = check(argv[2][0]);
	if (argc == 4 && argv[2][1] == '\0' && oper != 5)
	{
		if (ft_atoi(argv[3]) == 0 && (oper == 3 || oper == 4))
		{
			print_error();
			return (0);
		}
		res = calc(ft_atoi(argv[1]), ft_atoi(argv[3]), oper);
		ft_putnbr(res);
		ft_putchar('\n');
	}
	else
	{
		ft_putchar('0');
		ft_putchar('\n');
	}
	return (0);
}
