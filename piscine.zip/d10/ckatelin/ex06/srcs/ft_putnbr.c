/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/04 09:07:31 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/12 21:40:45 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_putnbr(int nb)
{
	int pwd;
	int num;

	pwd = 1;
	num = nb;
	while ((num >= 10) || (num <= -10))
	{
		num = num / 10;
		pwd = pwd * 10;
	}
	if (nb < 0)
		ft_putchar('-');
	while (pwd > 0)
	{
		num = ((nb / pwd) % 10);
		if (num < 0)
			num = num * (-1);
		ft_putchar(num + '0');
		pwd = pwd / 10;
	}
}
