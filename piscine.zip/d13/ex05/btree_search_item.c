/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_search_item.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ckatelin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/15 21:40:40 by ckatelin          #+#    #+#             */
/*   Updated: 2019/03/15 21:49:08 by ckatelin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	*btree_search_item(t_btree *root, void *data_ref,
			int (*cmpf)(void *, void *))
{
	t_btree	*elem;

	elem = root;
	if (!elem)
		return (0);
	if (cmpf(data_ref, elem->item) == 0)
		return (elem->item);
	if (elem->left)
		return (btree_search_item(elem->left, data_ref, cmpf));
	if (elem->right)
		return (btree_search_item(elem->right, data_ref, cmpf));
	return (0);
}
